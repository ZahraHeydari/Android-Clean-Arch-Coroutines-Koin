package com.android.post.presentation.posts

interface OnPostsActivityCallback {
}